# Research Agent — AI-Powered Academic & Scientific Research Assistant

**AICTE 2026 | IBM Skills Build for University Engagements | Problem Statement No.1**

## 📌 Problem Statement
A **Research Agent** is an AI system designed to assist with academic and scientific research
tasks. It autonomously searches for literature, summarizes papers, organizes references,
generates reports, suggests hypotheses, and drafts sections of research papers — saving time
on repetitive tasks like citation management and data extraction.

**Mandatory Technology:** IBM Cloud Lite services / IBM Granite

## 🧩 Problem Domain
Education & Academic Research

## 🤖 Solution Overview
A multi-agent AI system built on **IBM Bob**, **IBM watsonx.ai**, and **IBM Granite models**,
using a Retrieval-Augmented Generation (RAG) pipeline to ground responses in real academic
literature. The system is composed of four collaborating agents:

| Agent | Responsibility |
|---|---|
| Literature Search Agent | Retrieves relevant papers/articles from trusted academic sources |
| Summarization Agent | Condenses papers into concise summaries and key takeaways |
| Citation & Reference Agent | Organizes citations and generates bibliographies |
| Report & Draft Generation Agent | Drafts report sections and suggests hypotheses |

## 🏗️ Architecture
```
User Query
   │
   ▼
IBM Bob (Agent Orchestration)
   │
   ├── Literature Search Agent  ──► RAG Retrieval (Vector DB: FAISS/Chroma)
   ├── Summarization Agent      ──► IBM Granite Model
   ├── Citation & Reference Agent
   └── Report & Draft Generation Agent
   │
   ▼
Research Dashboard (search history, saved papers, citation graph, drafts)
```

## 🛠️ Technology Stack
- IBM Bob — visual multi-agent workflow orchestration
- IBM Granite model (e.g. `ibm-granite-3-2-8b`) — reasoning, summarization, generation
- IBM Cloud Lite services — hosting & scalable deployment
- IBM watsonx.ai — model deployment, embeddings, AI governance
- RAG (Retrieval-Augmented Generation) — grounded, trustworthy retrieval
- Vector Database (FAISS/Chroma) — literature & reference retrieval

## 📁 Repository Structure
```
├── README.md                          # This file
├── ProblemStatement.pdf                 # Official AICTE-2026 problem statement PDF
├── ProjectPresentation.pptx              # Final project submission PPT
├── agent_files/                          # All IBM Bob agent export/flow files
│   ├── agent_flow_export.json
│   └── agent_config.yaml
├── docs/                                 # Supporting documentation
│   └── architecture_notes.md
└── screenshots/                          # IBM Bob build & output screenshots
    ├── bob_screenshot_1.png
    └── output_screenshot_1.png
```

## ▶️ How to Run
1. Log in to **IBM Bob** and import `agent_files/agent_flow_export.json`.
2. Configure the IBM Granite model connection and IBM Cloud Lite credentials.
3. Load reference literature sources into the vector database (RAG index).
4. Run the flow and interact with the Research Agent via the chat/dashboard interface.

## 🔗 Links
- GitHub Repository: *(paste your public repo URL here)*
- IBM Bob Project Link: *(paste your IBM Bob shareable link here)*

## 👤 Submitted By
- Name: Mohammad Kaleem Shaiikh
- Institution:
- Email:
- AICTE Student ID:

## 📜 License
This project is submitted for academic purposes under the AICTE–IBM–Edunet Foundation
University Engagement Program 2026.
