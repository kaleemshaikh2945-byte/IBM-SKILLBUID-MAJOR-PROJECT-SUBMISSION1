# Architecture Notes — Research Agent

## Flow
1. User submits a research query (topic, question, or paper draft request) via the chat/dashboard.
2. **IBM Bob** routes the request to the relevant agent(s).
3. The **Literature Search Agent** performs RAG retrieval against the vector database
   (FAISS/Chroma), pulling from indexed sources such as arXiv, Google Scholar, and
   institutional repositories.
4. Retrieved documents are passed to the **Summarization Agent**, which uses the IBM
   Granite model to produce concise, digestible summaries.
5. The **Citation & Reference Agent** extracts metadata and formats citations/bibliography.
6. The **Report & Draft Generation Agent** synthesizes the above into hypothesis
   suggestions and draft report/paper sections.
7. Results are surfaced on the Research Dashboard (search history, saved papers,
   citation graph, draft progress).

## Notes for submission
- Replace `agent_files/agent_flow_export.json` with your actual IBM Bob export.
- Add IBM Bob build screenshots and output screenshots to `screenshots/`.
- Fill in the GitHub and IBM Bob links in `README.md`.
